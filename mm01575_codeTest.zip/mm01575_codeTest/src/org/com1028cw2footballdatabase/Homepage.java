package org.com1028cw2footballdatabase;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

public class Homepage {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Homepage window = new Homepage();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Homepage() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.LIGHT_GRAY);
		frame.getContentPane().setLayout(null);
		
		JButton btnTable = new JButton("Table");
		btnTable.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//TableChoice info = new TableChoice();
				TableChoice.main(null);
			}
		});
		btnTable.setFont(new Font("Tahoma", Font.BOLD, 30));
		btnTable.setBounds(78, 187, 171, 65);
		frame.getContentPane().add(btnTable);
		
		JButton btnResults = new JButton("Results");
		btnResults.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//Results info = new Results();
				Results.main(null);
			}
		});
		btnResults.setFont(new Font("Tahoma", Font.BOLD, 30));
		btnResults.setBounds(78, 301, 171, 65);
		frame.getContentPane().add(btnResults);
		
		JLabel lblHomepage = new JLabel("Welcome to Football League Data");
		lblHomepage.setHorizontalAlignment(SwingConstants.CENTER);
		lblHomepage.setFont(new Font("Rockwell Extra Bold", Font.PLAIN, 35));
		lblHomepage.setBounds(10, 22, 838, 83);
		frame.getContentPane().add(lblHomepage);
		
		JLabel image_label = new JLabel("");
		Image img=new ImageIcon(this.getClass().getResource("/Trophy.png")).getImage();
		image_label.setIcon(new ImageIcon(img));
		image_label.setBounds(341, 116, 400, 404);
		frame.getContentPane().add(image_label);
		frame.setBounds(100, 100, 867, 566);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	
	}
	

	public void setVisible(boolean b) {
		// TODO Auto-generated method stub
		
	}
}
