package org.com1028cw2footballdatabase;

import java.awt.Desktop;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.File;
import java.awt.event.ActionEvent;

public class Results {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Results window = new Results();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Results() {
		initialize();
	}

	
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 748, 514);
		frame.getContentPane().setLayout(null);
		
		JLabel lblResults = new JLabel("Results:");
		lblResults.setFont(new Font("OCR A Extended", Font.PLAIN, 30));
		lblResults.setBounds(35, 11, 224, 57);
		frame.getContentPane().add(lblResults);
		
		JButton button = new JButton("Season 15-16");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try{
					Desktop.getDesktop().open(new File("Results/Scores for 15-16.pdf"));
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		button.setFont(new Font("OCR A Extended", Font.BOLD, 20));
		button.setBounds(60, 147, 199, 63);
		frame.getContentPane().add(button);
		
		JButton btnSeason = new JButton("Season 16-17");
		btnSeason.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try{
					Desktop.getDesktop().open(new File("Results/Scores for 16-17.pdf"));
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		btnSeason.setFont(new Font("OCR A Extended", Font.BOLD, 20));
		btnSeason.setBounds(60, 246, 199, 63);
		frame.getContentPane().add(btnSeason);
		
		JButton btnSeason_1 = new JButton("Season 17-18");
		btnSeason_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try{
					Desktop.getDesktop().open(new File("Results/Scores for 17-18.pdf"));
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		btnSeason_1.setFont(new Font("OCR A Extended", Font.BOLD, 20));
		btnSeason_1.setBounds(60, 343, 199, 63);
		frame.getContentPane().add(btnSeason_1);
		
		JLabel lblChooseASeason = new JLabel("Choose a season:");
		lblChooseASeason.setFont(new Font("OCR A Extended", Font.PLAIN, 30));
		lblChooseASeason.setBounds(35, 66, 620, 57);
		frame.getContentPane().add(lblChooseASeason);
	}
}
