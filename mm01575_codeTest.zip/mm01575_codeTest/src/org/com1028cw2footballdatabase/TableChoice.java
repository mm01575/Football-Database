package org.com1028cw2footballdatabase;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.JLabel;

public class TableChoice {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TableChoice window = new TableChoice();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public TableChoice() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 613, 561);
		frame.getContentPane().setLayout(null);
		
		JButton btnSeason_2 = new JButton("Season 15-16");
		btnSeason_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//Table_15_16 info = new Table_15_16();
				Table_15_16.main(null);				
			}
		});
		btnSeason_2.setFont(new Font("OCR A Extended", Font.BOLD, 20));
		btnSeason_2.setBounds(77, 130, 199, 63);
		frame.getContentPane().add(btnSeason_2);
		
		JButton btnSeason_3 = new JButton("Season 16-17");
		btnSeason_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//Table_16_17 info = new Table_16_17();
				Table_16_17.main(null);
			}
		});
		btnSeason_3.setFont(new Font("OCR A Extended", Font.BOLD, 20));
		btnSeason_3.setBounds(77, 231, 199, 63);
		frame.getContentPane().add(btnSeason_3);
		
		JButton btnSeason_4 = new JButton("Season 17-18");
		btnSeason_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//Table_17_18 info = new Table_17_18();
				Table_17_18.main(null);
			}
		});
		btnSeason_4.setFont(new Font("OCR A Extended", Font.BOLD, 20));
		btnSeason_4.setBounds(77, 338, 199, 63);
		frame.getContentPane().add(btnSeason_4);
		
		JLabel lblChooseASeason = new JLabel("Choose a Season:");
		lblChooseASeason.setFont(new Font("OCR A Extended", Font.BOLD, 25));
		lblChooseASeason.setBounds(131, 27, 277, 78);
		frame.getContentPane().add(lblChooseASeason);
}
}
