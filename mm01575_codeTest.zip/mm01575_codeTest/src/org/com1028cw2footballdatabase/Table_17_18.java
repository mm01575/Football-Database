package org.com1028cw2footballdatabase;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.Color;
import java.awt.Font;

@SuppressWarnings("serial")
public class Table_17_18  extends JFrame {
	
	JTable tb;
	
	String[] column_headers = {"Position","Team","Played","Won","Drawn","Lost","Points"};
	String[][] statistics = {{"1","Team A", "10", "6", "4", "1", "22"} , {"2","Team B", "10", "5", "2", "4", "17"},
			{"3","Team F", "10", "4", "3", "3", "15"}, {"4","Team E", "10", "3", "1", "6", "10"}, {"5","Team C", "10", "3", "1", "6", "10"},
			{"6","Team D", "10", "3", "0", "4", "9"}};
	
	public Table_17_18() {
		tb = new JTable(statistics,column_headers);
		tb.setFont(new Font("Tahoma", Font.PLAIN, 15));
		tb.setBackground(Color.YELLOW);
		tb.setBounds(50,50,200,230);
		JScrollPane js = new JScrollPane(tb);
		getContentPane().add(js);
		this.setSize(631,171);
		this.setVisible(true);
			
	}
	public static void main(String[] args) {
		new Table_17_18();
	}
	
}
